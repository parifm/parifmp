# cephlab — Ceph 20.2.2 (Tentacle) as a Weka local object store, with rolling security patching

Validation build (2026-10-07) of an 8-host Ceph Tentacle cluster deployed with cephadm and orchestrated by Ansible (stackhpc.cephadm), used as the local object store (OBS) tier of a Weka 4.4.37 cluster. The goal was to prove rolling security patching of the Ceph backends, one host at a time with kexec instead of a full reboot, without disrupting Weka's use of the object store.

## Result
- All 8 Ceph hosts patched one at a time with `dnf upgrade -y --security` (kernel-core 6.12.0-211.16.1 -> 6.12.0-211.62.1 plus 48 package upgrades each) and restarted into the new kernel with kexec; 0 security updates left afterwards.
- About 3.5 minutes per host, including the wait for every PG to return to active+clean before the next host.
- Weka wrote continuously to the tiered filesystem at 48 MB/s throughout. Across ~17.4k S3 sessions the load balancer on the 6 Weka backends recorded 0 connection errors, 0 response errors and 0 retries (6 requests were transparently re-dispatched to another RGW). The Weka object store stayed UP the whole time, with no Weka events or new alerts.
- Ceph ended HEALTH_OK, 225/225 PGs active+clean, 5/5 MONs in quorum.

## Layout
| Item | Value |
|------|-------|
| Ceph hosts | cephlab-1..8: 4 OCPU (8 vCPU) / 32 GB VMs, Rocky Linux 10.2 |
| Disks per host | 2 x 500 GB HDD-class block volumes -> one OSD each; 1 x 200 GB SSD-class block volume -> DB/WAL for both OSDs (~107 GB each) |
| Daemons | 5 MON (cephlab-1..5), 3 MGR (cephlab-1..3), 16 OSD, 8 RGW (one per host, port 8080) |
| Data pool | `default.rgw.buckets.data`, erasure coded k=5 m=2, failure domain host, min_size 6; other RGW pools replicated x3 |
| Weka | 4.4.37, 6 backends, 3 clients; filesystem `obs` (2 TB, 200 GB SSD) tiered to bucket `weka-obs` |
| S3 front end | haproxy on every Weka backend at 127.0.0.1:8080, least-connections over the 8 RGWs, HTTP health check every 2 s (2 fails = down, 2 passes = up) |

Why 8 hosts for 5+2: with one host in maintenance, 7 of 8 failure domains remain, still above min_size 6, so writes continue and one further failure is tolerated.

Why a load balancer on each Weka backend: Weka's OBS connection takes one endpoint, and its S3 client uses the host kernel network stack, so a loopback haproxy gives it a single endpoint that rides through any one RGW restarting. A floating VIP (cephadm ingress with keepalived) was not used: on OCI a VIP does not move between VMs without an API call.

Why the OSD spec matches devices by size: the block volumes all report as rotational and have no stable by-name paths on Rocky, so `data_devices: size 400G:600G` and `db_devices: size 150G:250G` pick them unambiguously.

## Ansible (`ansible/`)
Run from an admin host with ssh access to every Ceph host (user `rocky`, passwordless sudo) and to the Weka backends (user `ubuntu`). Fill in `inventory/hosts.ini` and `cephadm_public_network` in `group_vars/all.yml` first.

| Play | What |
|------|------|
| `prep.yml` | hostnames, /etc/hosts, the pinned `rpm-20.2.2/el10` Ceph repo, podman / lvm2 / chrony |
| `site.yml` | stackhpc.cephadm: bootstrap, hosts, MON/MGR, OSD spec; EC profile and RGW pools; RGW service |
| `rgw_weka.yml` | S3 user and bucket for Weka |
| `haproxy_weka.yml` | haproxy on the Weka backends |
| `patch.yml` | rolling security patch (below) |
| `rolling_restart.yml` | rolling restart, optional full reboot (`-e reboot=true`) |
| `tasks/enter.yml` | take one host out of service |
| `tasks/exit.yml` | bring one host back |

Collections (`requirements.yml`): stackhpc.cephadm 1.23.3, containers.podman, ansible.posix, community.crypto, community.docker.

Weka side, after `rgw_weka.yml` and `haproxy_weka.yml`: add the bucket (`weka fs tier s3 add <name> --site local --hostname 127.0.0.1 --port 8080 --bucket weka-obs --auth-method AWSSignature4 --region default --protocol HTTP` plus the keys), create a filesystem group with a tiering policy, and create the tiered filesystem on it.

## Rolling security patch (`patch.yml`)
Per host, one at a time (`serial: 1`):
1. Skip the host if it is already fully patched (no security updates pending, newest kernel running, no restart needed). A rerun after a failure therefore resumes, and a patched host a failed run left in maintenance is only brought back.
2. Wait until every PG is active+clean. Stop if any other host is in maintenance.
3. Fail the MGR over if the active MGR is on this host; remove the host's `rgw` label and wait for its RGW to stop; enter maintenance (noout, all Ceph daemons on the host stopped).
4. `dnf upgrade -y --security`.
5. kexec into the newest installed kernel if it differs from the running one, or into the same kernel when `dnf needs-restarting -r` reports updated core libraries (`-e kexec_on_restart_needed=false` turns that off).
6. Sanity checks while still in maintenance:
   - running kernel = newest installed kernel
   - boot finished and no failed systemd units (except `dnf-makecache.service`)
   - clock synced within 50 ms (`chronyc waitsync`), the MON clock-skew limit
   - podman works and sees the new kernel
   - all 4 OSD logical volumes (2 block, 2 DB) present and active
   - every other Ceph host reachable on the private network
   - no further restart needed and no security updates left
7. Exit maintenance, restore the `rgw` label, then wait for the host's OSDs up, every PG active+clean, every daemon on the host running, all 8 RGWs running and HEALTH_OK before moving on.

Any failed step stops the run with the host left in maintenance and its `rgw` label restored, for inspection.

The admin host cannot patch itself (kexec would end the run), so the play refuses it. Patch it from a second admin host: `ansible-playbook patch.yml --limit cephlab-1`, run from cephlab-2. A dedicated admin VM outside the Ceph cluster avoids this second step.

## Findings
- **stackhpc.cephadm 1.23.3 maintenance roles vs Ceph 20.2:** `ceph orch host ok-to-stop` exits 16 (EBUSY) for a host running an RGW or the active MGR, and the role runs that check before its own RGW drain and MGR failover, so the stock `enter_maintenance` role fails on every host. `tasks/enter.yml` drains the RGW and fails the MGR over first, after which the role works.
- **dnf module vs dnf CLI:** Ansible's `dnf` module with `security: true` pins each package to its advisory version and failed to resolve (openssl-libs 3.5.5 from an advisory against a libcurl update that requires 3.5.8). The CLI `dnf upgrade -y --security` resolves it, so the play runs the CLI.
- **cephadm role applies its service spec only at bootstrap,** so `site.yml` applies the RGW service with `ceph orch apply` after the pools exist (this also keeps RGW from creating a replicated data pool).
- **`.rgw.root` cannot be pre-created** (Ceph refuses user pool names starting with "."); RGW creates it.
- **The host `ceph` CLI package for el10 needs lua-devel and luarocks** (CRB and EPEL); the plays use `cephadm shell` instead (`cephadm_install_ceph_cli: false`).
- **`rpm-tentacle` follows the newest 20.2.x** (20.2.4 at the time), so the repo is pinned to `rpm-20.2.2`.

## Files
- `ansible/`: plays, task files, group_vars, placeholder inventory.
- `provision/`: OCI CLI templates (`launch.sh`, `attach.sh`, `gen_inventory.sh`); tenancy IDs and tags come from environment variables.
- `logs/`: Ansible run logs with addresses, identifiers and timestamps replaced by placeholders. `patch-2to7.log` and `patch-ceph1.log` are the full patch pass; `patch-ceph8*.log` are the canary runs that found the dnf and resume issues; `rr-*.log` are the restart runs that found the `ok-to-stop` issue.
