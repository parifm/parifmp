#!/usr/bin/env bash
# Print the [ceph] inventory lines (private IPs) for the launched cephlab-N instances; paste into ../ansible/inventory/hosts.ini.
# Usage: COMPARTMENT=... gen_inventory.sh
set -euo pipefail
: "${OCI_CLI_REGION:?set OCI_CLI_REGION}"
: "${COMPARTMENT:?compartment OCID}"
HERE=$(cd "$(dirname "$0")" && pwd)
for f in "$HERE"/instances/cephlab-*.instance; do
  n=$(basename "$f" .instance)
  ip=$(oci compute vnic-attachment list -c "$COMPARTMENT" --instance-id "$(cat "$f")" --query 'data[0]."vnic-id"' --raw-output \
    | xargs -I{} oci network vnic get --vnic-id {} --query 'data."private-ip"' --raw-output)
  echo "$n ansible_host=$ip"
done | sort -t- -k2 -n
