#!/usr/bin/env bash
# Attach each cephlab-N host's three volumes (paravirtualized) once the instance is RUNNING and the volumes AVAILABLE.
# Usage: attach.sh <n>...
set -euo pipefail
: "${OCI_CLI_REGION:?set OCI_CLI_REGION}"
OUT=$(cd "$(dirname "$0")" && pwd)/instances

wait_state() {  # $1 = instance|volume, $2 = ocid, $3 = wanted state
  local s i
  for i in $(seq 1 90); do
    if [ "$1" = instance ]; then
      s=$(oci compute instance get --instance-id "$2" --query 'data."lifecycle-state"' --raw-output)
    else
      s=$(oci bv volume get --volume-id "$2" --query 'data."lifecycle-state"' --raw-output)
    fi
    [ "$s" = "$3" ] && return 0
    case $s in TERMINATED|TERMINATING|FAULTY) echo "$2 is $s" >&2; return 1;; esac
    sleep 10
  done
  echo "$2 still $s after 15 min" >&2; return 1
}

for n in "$@"; do
  iid=$(cat "$OUT/cephlab-$n.instance")
  wait_state instance "$iid" RUNNING
  for role in data1 data2 db; do
    vid=$(cat "$OUT/cephlab-$n.$role.volume")
    wait_state volume "$vid" AVAILABLE
    oci compute volume-attachment attach --instance-id "$iid" --volume-id "$vid" --type paravirtualized \
      --wait-for-state ATTACHED --max-wait-seconds 600 --query 'data."lifecycle-state"' --raw-output | tail -1 | sed "s/^/cephlab-$n $role /"
  done
done
