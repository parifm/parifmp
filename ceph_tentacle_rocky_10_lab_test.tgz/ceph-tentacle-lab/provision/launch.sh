#!/usr/bin/env bash
# Launch cephlab-N hosts on OCI: E5.Flex 4 OCPU / 32 GB, Rocky 10.2, public IP (for package and container pulls),
# 2 x 500 GB Lower Cost (VPU 0) data volumes + 1 x 200 GB Higher Performance (VPU 20) DB/WAL volume.
# Usage: COMPARTMENT=... SUBNET=... NSG=... AD=... IMAGE=... [DEFINED_TAGS='{...}'] [FREEFORM_TAGS='{...}'] launch.sh <n>...
set -euo pipefail
: "${OCI_CLI_REGION:?set OCI_CLI_REGION}"
: "${COMPARTMENT:?compartment OCID}" "${SUBNET:?subnet OCID}" "${NSG:?NSG OCID}" "${AD:?availability domain}"
: "${IMAGE:?imported Rocky 10.2 image OCID}"
DEFINED_TAGS=${DEFINED_TAGS:-'{}'}
FREEFORM_TAGS=${FREEFORM_TAGS:-'{}'}
HERE=$(cd "$(dirname "$0")" && pwd)
KEYS=${SSH_KEYS:-$HERE/authorized_keys}
OUT=$HERE/instances
mkdir -p "$OUT"

for n in "$@"; do
  name=cephlab-$n
  fd=FAULT-DOMAIN-$(( (n - 1) % 3 + 1 ))
  iid=$(oci compute instance launch -c "$COMPARTMENT" --availability-domain "$AD" --fault-domain "$fd" \
    --shape VM.Standard.E5.Flex --shape-config '{"ocpus":4,"memoryInGBs":32}' \
    --image-id "$IMAGE" --boot-volume-size-in-gbs 50 \
    --subnet-id "$SUBNET" --nsg-ids "[\"$NSG\"]" --assign-public-ip true \
    --display-name "$name" \
    --ssh-authorized-keys-file "$KEYS" \
    --defined-tags "$DEFINED_TAGS" --freeform-tags "$FREEFORM_TAGS" \
    --query data.id --raw-output)
  echo "$name $iid"
  echo "$iid" > "$OUT/$name.instance"
  for v in data1:500:0 data2:500:0 db:200:20; do
    IFS=: read -r role gb vpu <<<"$v"
    vid=$(oci bv volume create -c "$COMPARTMENT" --availability-domain "$AD" --size-in-gbs "$gb" --vpus-per-gb "$vpu" \
      --display-name "$name-$role" --defined-tags "$DEFINED_TAGS" --freeform-tags "$FREEFORM_TAGS" --query data.id --raw-output)
    echo "$vid" > "$OUT/$name.$role.volume"
    echo "  $role ${gb}GB vpu=$vpu $vid"
  done
done
