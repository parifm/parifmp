#ifndef __PLX_CHIP_FN_H
#define __PLX_CHIP_FN_H

/*******************************************************************************
 * Copyright 2013-2015 Avago Technologies
 * Copyright (c) 2009 to 2012 PLX Technology Inc.  All rights reserved.
 *
 * This software is available to you under a choice of one of two
 * licenses.  You may choose to be licensed under the terms of the GNU
 * General Public License (GPL) Version 2, available from the file
 * COPYING in the main directorY of this source tree, or the
 * BSD license below:
 *
 *     Redistribution and use in source and binary forms, with or
 *     without modification, are permitted provided that the following
 *     conditions are met:
 *
 *      - Redistributions of source code must retain the above
 *        copyright notice, this list of conditions and the following
 *        disclaimer.
 *
 *      - Redistributions in binary form must reproduce the above
 *        copyright notice, this list of conditions and the following
 *        disclaimer in the documentation and/or other materials
 *        provided with the distribution.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 * BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 * ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 ******************************************************************************/

/******************************************************************************
 *
 * File Name:
 *
 *      PlxChipFn.h
 *
 * Description:
 *
 *      Header for PLX chip-specific support functions
 *
 * Revision History:
 *
 *      03-01-10 : PLX SDK v6.40
 *
 ******************************************************************************/

#include "DrvDefs.h"

/**********************************************
 *               Functions
 *********************************************/
BOOLEAN
PlxChipInterruptsEnable(DEVICE_EXTENSION* pdx);

BOOLEAN
PlxChipInterruptsDisable(DEVICE_EXTENSION* pdx);

VOID PlxChipSetInterruptNotifyFlags(PLX_INTERRUPT* pPlxIntr,
                                    PLX_WAIT_OBJECT* pWaitObject);

VOID PlxChipSetInterruptStatusFlags(PLX_INTERRUPT_DATA* pIntData,
                                    PLX_INTERRUPT* pPlxIntr);

PLX_STATUS
PlxChipTypeDetect(DEVICE_EXTENSION* pdx);

VOID PlxChipGetRemapOffset(DEVICE_EXTENSION* pdx, U8 BarIndex,
                           U16* Offset_RegRemap);

#endif
