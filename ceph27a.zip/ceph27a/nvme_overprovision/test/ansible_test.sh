#!/usr/bin/env bash
# Run the role on localhost against the mock host from mock_test.sh (install tasks skipped):
# wrong expected count fails untouched, plan-only changes nothing, apply resizes both RI drives, rerun is a no-op.
# Usage: test/ansible_test.sh <empty work dir>
set -euo pipefail
HERE=$(cd "$(dirname "$0")" && pwd)
W=${1:?work dir}; mkdir -p "$W"; W=$(cd "$W" && pwd)
export ST=$W/state NVME_OP_SYSFS=$W/sys NVME_OP_DEV=$W/dev
export PATH="$W/bin:$(dirname "$(command -v bash)"):$PATH" ANSIBLE_ROLES_PATH=$HERE/../roles
cat >"$W/play.yml" <<EOF
- hosts: localhost
  connection: local
  gather_facts: false
  vars:
    nvme_op_models: ["MOCK RI 7.68TB"]
    nvme_op_script: $HERE/../roles/nvme_overprovision/files/nvme-op.sh
  roles: [nvme_overprovision]
EOF
pb() { ansible-playbook -i localhost, --skip-tags install "$W/play.yml" "$@"; }
sizes() { cat "$ST/nvme0/ns/1/nsze" "$ST/nvme1/ns/1/nsze" "$ST/nvme2/ns/1/nsze" | paste -sd' ' -; }
pass=0; fail=0
check() { if [ "$2" = "$3" ]; then pass=$((pass+1)); echo "ok   $1"; else fail=$((fail+1)); echo "FAIL $1: expected [$2] got [$3]"; fi; }
FACT="15002931888 15002931888 15002931888"

"$HERE/mock_test.sh" "$W" setup
r=0; pb -e nvme_op_expected_per_host=3 -e nvme_op_apply=true >"$W/run1.log" 2>&1 || r=$?
check "count mismatch fails"   2 "$r"
check "count mismatch: untouched" "$FACT" "$(sizes)"
mkdir -p "$ST/blkid"; echo ceph_bluestore >"$ST/blkid/nvme1n1"
r=0; pb -e nvme_op_expected_per_host=2 -e nvme_op_apply=true >"$W/run1b.log" 2>&1 || r=$?
check "Ceph label fails the play" 2 "$r"
check "Ceph label: nothing touched, other drive included" "$FACT" "$(sizes)"
rm -rf "$ST/blkid"
r=0; pb -e nvme_op_expected_per_host=2 >"$W/run2.log" 2>&1 || r=$?
check "plan only passes"       0 "$r"
check "plan only: untouched"   "$FACT" "$(sizes)"
r=0; pb -e nvme_op_expected_per_host=2 -e nvme_op_apply=true >"$W/run3.log" 2>&1 || r=$?
check "apply passes"           0 "$r"
check "apply: RI resized, boot untouched" "12500000000 12500000000 15002931888" "$(sizes)"
r=0; pb -e nvme_op_expected_per_host=2 -e nvme_op_apply=true >"$W/run4.log" 2>&1 || r=$?
check "rerun passes"           0 "$r"
check "rerun: nothing changed" "changed=0" "$(grep -oE 'changed=[0-9]+' "$W/run4.log")"
check "rerun: host ended early" 1 "$(grep -c "Every drive already formatted" "$W/run4.log")"
check "rerun: resize never reached" 0 "$(grep -c "TASK \[nvme_overprovision : Resize\]" "$W/run4.log" || true)"
echo "$pass passed, $fail failed (logs in $W)"
[ "$fail" = 0 ]
