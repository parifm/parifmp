#!/usr/bin/env bash
# Exercise nvme-op.sh against fake nvme/lsblk/blockdev/udevadm commands and a fake /sys/class/nvme.
# Needs bash 4+ and jq. Proves the script's logic only; it says nothing about real drives or nvme-cli.
# Usage: test/mock_test.sh <empty work dir>
set -euo pipefail
HERE=$(cd "$(dirname "$0")" && pwd)
OP=$HERE/../roles/nvme_overprovision/files/nvme-op.sh
W=${1:?work dir}; mkdir -p "$W"; W=$(cd "$W" && pwd)
export ST=$W/state NVME_OP_SYSFS=$W/sys NVME_OP_DEV=$W/dev
BIN=$W/bin; mkdir -p "$BIN"
export PATH="$BIN:$(dirname "$(command -v bash)"):$PATH"
FACTORY=15002931888   # 7.68 TB in 512 B blocks
RI="MOCK RI 7.68TB"

cat >"$BIN/nvme" <<'EOF'
#!/usr/bin/env bash
# Fake nvme-cli: state in $ST/<ctrl>/{mn,sn,oacs,cntlid,tnvm,round}, $ST/<ctrl>/ns/<nsid>/{nsze,flbas,att}
set -euo pipefail
cmd=$1; shift; dev=${1:-}; c=$(basename "$dev"); S=$ST/$c
arg() { local k=$1 a; for a in "${ARGS[@]}"; do case $a in --$k=*) echo "${a#*=}";; esac; done; }
ARGS=("$@"); nsopt=""; all=0; i=0
while [ $i -lt ${#ARGS[@]} ]; do case ${ARGS[$i]} in -n) nsopt=${ARGS[$((i+1))]};; -a) all=1;; esac; i=$((i+1)); done
bs() { [ "$(cat "$1/flbas")" = 1 ] && echo 4096 || echo 512; }
used() { local u=0 n; for n in "$S"/ns/*; do [ -d "$n" ] && u=$((u + $(cat "$n/nsze") * $(bs "$n"))); done; echo $u; }
expose() { local n b; for n in "$S"/ns/*; do [ -d "$n" ] || continue; b=$(basename "$n")
  if [ "$(cat "$n/att")" = 1 ]; then mkdir -p "$NVME_OP_SYSFS/$c/${c}n$b"; touch "$NVME_OP_DEV/${c}n$b"; fi; done; }
case $cmd in
  id-ctrl) t=$(cat "$S/tnvm"); jq -n --arg mn "$(cat "$S/mn")   " --arg sn "$(cat "$S/sn")" --argjson oacs "$(cat "$S/oacs")" \
             --argjson cntlid "$(cat "$S/cntlid")" --argjson t "$t" --argjson u "$((t - $(used) - ${MOCK_UNVM_SHORT:-0}))" \
             '{mn:$mn, sn:$sn, fr:"MOCK1", oacs:$oacs, cntlid:$cntlid, tnvmcap:$t, unvmcap:$u}' ;;
  list-ns) k=0; for n in $(ls "$S/ns" | sort -n); do
             if [ $all = 1 ] || [ "$(cat "$S/ns/$n/att")" = 1 ]; then printf '[%4u]:%#x\n' $k "$n"; k=$((k+1)); fi; done ;;
  id-ns) lb='[{"ms":0,"ds":9},{"ms":0,"ds":12},{"ms":8,"ds":9}]'
         if [ "$nsopt" = 0xffffffff ]; then echo "{\"lbafs\":$lb}"
         else n=$S/ns/$((nsopt)); jq -n --argjson z "$(cat "$n/nsze")" --argjson f "$(cat "$n/flbas")" --argjson lb "$lb" \
           '{nsze:$z, ncap:$z, flbas:$f, dps:0, lbafs:$lb}'; fi ;;
  detach-ns) echo 0 >"$S/ns/$nsopt/att"; rm -rf "$NVME_OP_SYSFS/$c/${c}n$nsopt" "$NVME_OP_DEV/${c}n$nsopt"; echo "detach-ns: Success, nsid:$nsopt" ;;
  delete-ns) [ "$(cat "$S/ns/$nsopt/att")" = 0 ] || { echo "delete-ns: attached" >&2; exit 1; }; rm -rf "$S/ns/$nsopt"; echo "delete-ns: Success, deleted nsid:$nsopt" ;;
  create-ns) n=1; while [ -d "$S/ns/$n" ]; do n=$((n+1)); done; mkdir -p "$S/ns/$n"
             echo $(( $(arg nsze) + $(cat "$S/round") )) >"$S/ns/$n/nsze"; arg flbas >"$S/ns/$n/flbas"; echo 0 >"$S/ns/$n/att"
             if [ "${MOCK_CLI:-2.16}" = 2.11 ]; then echo "create-ns: Success, created nsid:$n"; else printf 'create-ns: success\nnsid: %d\n' "$n"; fi ;;
  attach-ns) echo 1 >"$S/ns/$nsopt/att"; echo "attach-ns: Success, nsid:$nsopt" ;;
  reset) echo "reset $c" ;;
  ns-rescan) expose ;;
  list) for s in "$ST"/nvme*; do echo "/dev/$(basename "$s") $(cat "$s/sn") $(cat "$s/mn")"; done ;;
  *) echo "mock nvme: $cmd unsupported" >&2; exit 2 ;;
esac
EOF
cat >"$BIN/lsblk" <<'EOF'
#!/usr/bin/env bash
d=${!#}; f=$ST/lsblk/$(basename "$d")
if [ -f "$f" ]; then cat "$f"; else echo "NAME=\"$d\" TYPE=\"disk\" MOUNTPOINTS=\"\""; fi
EOF
cat >"$BIN/blkid" <<'EOF'
#!/usr/bin/env bash
# $ST/blkid/<dev>: the TYPE value; absent = nothing found (rc 2, like blkid -p); "FAIL" = probe error (rc 4)
f=$ST/blkid/$(basename "${!#}")
[ -f "$f" ] || exit 2
[ "$(cat "$f")" = FAIL ] && exit 4
cat "$f"
EOF
cat >"$BIN/blockdev" <<'EOF'
#!/usr/bin/env bash
b=$(basename "$2"); c=${b%n*}; n=${b##*n}; s=$ST/$c/ns/$n
[ "$(cat "$s/flbas")" = 1 ] && bs=4096 || bs=512; echo $(( $(cat "$s/nsze") * bs ))
EOF
printf '#!/bin/sh\nexit 0\n' >"$BIN/udevadm"; printf '#!/bin/sh\nexit 0\n' >"$BIN/sleep"
chmod +x "$BIN"/*

drive() {  # ctrl model serial [oacs] [subsys]
  local c=$1 S=$ST/$1; rm -rf "$S" "$NVME_OP_SYSFS/$c"; mkdir -p "$S/ns/1" "$NVME_OP_SYSFS/$c" "$NVME_OP_DEV"
  echo "$2" >"$S/mn"; echo "$3" >"$S/sn"; echo "${4:-14}" >"$S/oacs"; echo $((0x40 + ${c#nvme})) >"$S/cntlid"
  echo 7681501126656 >"$S/tnvm"; echo 0 >"$S/round"
  echo $FACTORY >"$S/ns/1/nsze"; echo 0 >"$S/ns/1/flbas"; echo 1 >"$S/ns/1/att"
  echo "${5:-nqn.mock:$3}" >"$NVME_OP_SYSFS/$c/subsysnqn"; echo live >"$NVME_OP_SYSFS/$c/state"
  mkdir -p "$NVME_OP_SYSFS/$c/${c}n1"; touch "$NVME_OP_DEV/${c}n1"
}
reset_all() {
  rm -rf "$ST" "$NVME_OP_SYSFS" "$NVME_OP_DEV"; mkdir -p "$ST/lsblk"
  drive nvme0 "$RI" S0; drive nvme1 "$RI" S1; drive nvme2 "MOCK BOOT 960GB" B2
  echo "NAME=\"$NVME_OP_DEV/nvme2n1\" TYPE=\"disk\" FSTYPE=\"\" PTTYPE=\"gpt\" MOUNTPOINTS=\"\"
NAME=\"$NVME_OP_DEV/nvme2n1p1\" TYPE=\"part\" FSTYPE=\"xfs\" PTTYPE=\"gpt\" MOUNTPOINTS=\"/\"" >"$ST/lsblk/nvme2n1"
}

# `setup`: build the fake host (2 RI drives + a boot drive) and stop, for test/ansible_test.sh.
if [ "${2:-}" = setup ]; then reset_all; exit 0; fi

export NVME_OP_MODELS=$RI
pass=0; fail=0
state_of() { "$OP" plan | jq -r --arg c "$1" 'select(.ctrl == $c) | .state'; }
check() {  # name expected actual
  if [ "$2" = "$3" ]; then pass=$((pass+1)); echo "ok   $1"; else fail=$((fail+1)); echo "FAIL $1: expected [$2] got [$3]"; fi
}

reset_all
check "factory drives are todo"        "todo todo skip" "$(state_of nvme0) $(state_of nvme1) $(state_of nvme2)"
check "6.4 TB in 512 B blocks"         12500000000 "$("$OP" plan | jq -r 'select(.ctrl=="nvme0") | .nsze_target')"
out=$("$OP" apply S0); echo "$out" | sed 's/^/     | /'
check "apply resizes"                  done "$(state_of nvme0)"
check "drive now 6.4e12 B"             6400000000000 "$(blockdev --getsize64 "$NVME_OP_DEV/nvme0n1")"
check "unallocated = OP space"         1281501126656 "$(nvme id-ctrl "$NVME_OP_DEV/nvme0" -o json | jq .unvmcap)"
check "apply again is a no-op"         "already done" "$("$OP" apply S0 | grep -o 'already done')"
check "boot drive untouched"           "$FACTORY" "$(cat "$ST/nvme2/ns/1/nsze")"
check "allow-listed but mounted: blocked" blocked "$(NVME_OP_MODELS="$RI,MOCK BOOT 960GB" state_of nvme2)"

# Ceph check on nvme1 (factory namespace). Each case sets one condition, checks, then clears it.
mkdir -p "$ST/blkid"
reason_of() { "$OP" plan | jq -r --arg c "$1" 'select(.ctrl == $c) | .reason'; }
B=$NVME_OP_DEV/nvme1n1
echo ceph_bluestore >"$ST/blkid/nvme1n1"
check "raw BlueStore label blocks"     blocked "$(state_of nvme1)"
check "reason names it"                "$B has a Ceph BlueStore label" "$(reason_of nvme1)"
check "apply refuses blocked"          1 "$(r=0; "$OP" apply S1 >"$W/out" 2>&1 || r=$?; echo $r)"
check "blocked drive untouched"        "$FACTORY" "$(cat "$ST/nvme1/ns/1/nsze")"
echo LVM2_member >"$ST/blkid/nvme1n1"
check "LVM PV (inactive) blocks"       blocked "$(state_of nvme1)"
echo FAIL >"$ST/blkid/nvme1n1"
check "blkid probe error blocks"       blocked "$(state_of nvme1)"
echo xfs >"$ST/blkid/nvme1n1"
check "non-Ceph filesystem: todo"      todo "$(state_of nvme1)"
rm "$ST/blkid/nvme1n1"
printf '%s\n' "NAME=\"$B\" TYPE=\"disk\" MOUNTPOINTS=\"\"" "NAME=\"${B}p1\" TYPE=\"part\" MOUNTPOINTS=\"\"" >"$ST/lsblk/nvme1n1"
check "plain partition: todo"          todo "$(state_of nvme1)"
echo LVM2_member >"$ST/blkid/nvme1n1p1"
check "LVM PV on a partition blocks"   blocked "$(state_of nvme1)"
rm "$ST/blkid/nvme1n1p1"
printf '%s\n' "NAME=\"$B\" TYPE=\"disk\" MOUNTPOINTS=\"\"" "NAME=\"/dev/mapper/ceph--x-osd--block--y\" TYPE=\"lvm\" MOUNTPOINTS=\"\"" >"$ST/lsblk/nvme1n1"
check "active OSD LV blocks"           blocked "$(state_of nvme1)"
rm "$ST/lsblk/nvme1n1"
rm "$NVME_OP_DEV/nvme1n1"
check "attached but no block device blocks" blocked "$(state_of nvme1)"
touch "$NVME_OP_DEV/nvme1n1"
check "all cleared: todo again"        todo "$(state_of nvme1)"

check "serial filter skips others"     "skip todo" "$(NVME_OP_SERIALS=S1 state_of nvme0) $(NVME_OP_SERIALS=S1 state_of nvme1)"
check "lbaf 1 makes a 512 B drive todo" todo "$(NVME_OP_LBAF=1 state_of nvme0)"
NVME_OP_LBAF=1 "$OP" apply S0 >"$W/out"
check "4K resize: 1562500000 blocks"   "done 1562500000 4096" "$(NVME_OP_LBAF=1 "$OP" plan | jq -r 'select(.ctrl=="nvme0") | "\(.state) \(.nsze_now) \(.block_size)"')"
check "metadata format refused"        blocked "$(NVME_OP_LBAF=2 state_of nvme1)"

echo 8 >"$ST/nvme1/round"
check "rounding drive fails verify"    1 "$(r=0; "$OP" apply S1 >"$W/out" 2>&1 || r=$?; echo $r)"
check "rounding message names nvme_op_nsze" 1 "$(grep -c 'nvme_op_nsze' "$W/out")"
check "nsze override then done"        done "$(NVME_OP_NSZE=12500000008 state_of nvme1)"

reset_all
rm -rf "$ST/nvme1/ns/1" "$NVME_OP_SYSFS/nvme1/nvme1n1" "$NVME_OP_DEV/nvme1n1"
check "no namespace, no lbaf: blocked" blocked "$(state_of nvme1)"
check "no namespace, lbaf 0: todo"     todo "$(NVME_OP_LBAF=0 state_of nvme1)"
NVME_OP_LBAF=0 "$OP" apply S1 >"$W/out"
check "interrupted drive recovered"    done "$(state_of nvme1)"

reset_all
MOCK_CLI=2.11 "$OP" apply S0 >"$W/out"
check "nvme-cli 2.11 create-ns output parsed" done "$(state_of nvme0)"
MOCK_UNVM_SHORT=4096 "$OP" apply S1 >"$W/out"
check "unvmcap slightly under tnvmcap still resizes" done "$(state_of nvme1)"

drive nvme1 "$RI" S1 6
check "no NS management: blocked"      blocked "$(state_of nvme1)"
drive nvme1 "$RI" S1 14 nqn.mock:shared; echo nqn.mock:shared >"$NVME_OP_SYSFS/nvme0/subsysnqn"
check "two controllers, one subsystem: blocked" "blocked blocked" "$(state_of nvme0) $(state_of nvme1)"

echo "$pass passed, $fail failed"
[ "$fail" = 0 ]
