# nvme_overprovision: 7.68 TB RI NVMe drives as 6.4 TB MU-equivalents (ceph27a)

Draft for Simon, from Don's request (2026-10-10): https://wekaio.slack.com/archives/C0C3HTY8MGR/p1791642551022249 . Each allow-listed NVMe drive is left with exactly one namespace of the target size (default 6.4 TB decimal). The drive never allocates the remaining ~1.28 TB, so it serves as over-provisioning. Not using space inside a filesystem does not achieve this; the space must never be allocated to a namespace.

**Status: never run on real hardware.** Tested only against a mock nvme-cli (see Tests). The first real run should be plan-only, then a one-host canary.

## Files
| Path | What |
|------|------|
| `nvme_op.yml` | Example play: canary order 1 host, 10, then the rest; any failure stops the run |
| `roles/nvme_overprovision/defaults/main.yml` | Every input, commented |
| `roles/nvme_overprovision/tasks/main.yml` | Install, plan, assert, resize, re-plan |
| `roles/nvme_overprovision/files/nvme-op.sh` | The logic (bash + jq), installed as `/usr/local/sbin/nvme-op`; runs on its own too |
| `test/mock_test.sh`, `test/ansible_test.sh` | Mock tests (no hardware) |

## What it does, per drive
Don's steps, with checks around them:
1. **Plan** (always). For every NVMe controller: `nvme id-ctrl`, `nvme list-ns` (attached and `--all`), `nvme id-ns`. The drive's state is:
   - `skip`: model not in `nvme_op_models`, or serial not in `nvme_op_serials`
   - `done`: exactly one namespace, attached, `nsze == ncap ==` target, target LBA format
   - `blocked`: no namespace management support (OACS bit 3), more than one controller in the subsystem (dual-port), the target is not below capacity, an unsupported or metadata LBA format, or **Ceph has something on the drive**. There is no override.
     - The Ceph check covers the namespace and any partitions on it. A drive is blocked when any of these is true:
       - something on it is mounted
       - it has active LVM, dm or md on top
       - `blkid -p` finds a BlueStore label or an LVM PV. These are the two ways ceph-volume lays out an OSD, and `blkid -p` reads the disk itself, not the udev cache.
       - `blkid` fails
     - Drives already in the target format (`done`) are never inspected, so a resized drive in service as an OSD is left alone.
   - `todo`: everything else
2. **Assert**, before anything changes:
   - The number of non-skipped drives equals `nvme_op_expected_per_host`, or the number of `nvme_op_serials`.
   - No drive is blocked.

   A wrong model string, or drives behind a tri-mode HBA that shows them as `/dev/sdX`, therefore fails the run instead of passing with nothing done.
3. **Resize** (`nvme_op_apply=true` only), for each todo drive:
   1. `detach-ns`, then `delete-ns`, for every namespace
   2. Check no namespace is left and `unvmcap == tnvmcap`
   3. `create-ns --nsze=N --ncap=N --flbas=F --dps=0`, then `attach-ns -c <cntlid>`
   4. `nvme reset` (wait for the controller to come back up), `nvme ns-rescan`, wait for the block device
   5. **Verify:** re-plan shows `done`, and `blockdev --getsize64` equals N × block size
4. **Re-plan:** every targeted drive must now be `done`.

Rerunning is safe. A host whose drives are all `done` ends the play right after the plan (`meta: end_host`). A drive that stopped after the delete step (no namespaces) is recovered once you set `nvme_op_lbaf`.

## Inputs (group_vars)
| Variable | Default | Notes |
|----------|---------|-------|
| `nvme_op_models` | `[]` (required) | Exact `mn` strings from `nvme id-ctrl` |
| `nvme_op_expected_per_host` | required | Allow-listed drives per host |
| `nvme_op_serials` | `[]` | Spare replacement: only these serials |
| `nvme_op_target_bytes` | `6400000000000` | Target size, decimal bytes |
| `nvme_op_nsze` | empty | Exact block count. Overrides the bytes; use the vendor's MU number if they publish one |
| `nvme_op_lbaf` | empty = keep factory | LBA format index (see open questions) |
| `nvme_op_apply` | `false` | `false` = plan only |
| `nvme_op_reset` | `true` | Controller reset after attach |

The inventory group is `nvme_op`; override it with `-e nvme_op_hosts=<group>`.

## Running
```
ansible-playbook nvme_op.yml                          # plan every host; read the per-drive lines
ansible-playbook nvme_op.yml -e nvme_op_apply=true    # resize: 1 host, then 10, then the rest
```
Spare replacement (one host, one drive):
```
ansible-playbook nvme_op.yml --limit <host> -e nvme_op_apply=true -e '{"nvme_op_serials":["<serial>"]}'
```
On the host itself: `NVME_OP_MODELS='<model>' nvme-op plan`.

A plan-only run stops at the first host that fails its assert, because of the canary batches and `any_errors_fatal`. To get a full-fleet plan, run the script on every host in one pass:
```
ansible nvme_op -b -m command -a '/usr/local/sbin/nvme-op plan' -e ...
```
That needs the role installed once first, with the `NVME_OP_*` environment set.

## Keep cephadm off un-resized drives
A new or replacement drive arrives with its factory 7.68 TB namespace. An OSD spec that takes any available device can make it an OSD before this role runs, and then the drive shows as `blocked` (in use). Match the OSD spec by size, so that only resized drives qualify:
```yaml
spec:
  data_devices:
    size: "5500G:6500G"   # resized 6.4e12 B drive reads 5.82 "TB": in. Factory 7.68e12 B reads 6.99 "TB": out.
```
Why the range is odd, from Ceph v20.2.2 source:
- ceph-volume's `human_readable_size` divides by 1024 but labels the result "TB".
- `SizeMatcher` multiplies that label by 10¹².
- So a 6.4e12 B drive compares as 5.82e12 and a 7.68e12 B drive as 6.99e12.
- The low:high form only accepts whole numbers (`6T:6.6T` does not parse).
- 5500G:6500G holds 5.82e12 (and 6.4e12, in case this is ever fixed) and excludes 6.99e12 and 7.68e12.

Confirm with `ceph orch device ls` on the first host before applying the spec.

## Open questions (Don, Simon)
- **Drive model and firmware:** we need the exact model. Confirm both:
  - namespace management is supported (OACS bit 3)
  - the vendor treats unallocated capacity as over-provisioning

  Some vendors document an exact MU-equivalent block count; if so, set `nvme_op_nsze` to it.
- **LBA format (512 vs 4K):** the default keeps the factory format, and the plan prints it. 4K is usually the better fit for BlueStore. If you choose it, set `nvme_op_lbaf` to the 4K index from `nvme id-ns -H`. That makes every drive `todo` again, including resized ones, so decide before the first apply.
- **Tri-mode controller:** if the HPE chassis puts the drives behind a tri-mode HBA, they appear as `/dev/sdX` and NVMe namespace commands cannot reach them. The count assert catches this, but the procedure would need a different route.
- **Dual-port drives:** if the subsystem shows more than one controller, the drive is `blocked`. Attach-list handling for that case was left out on purpose.
- **Rounding:** if a drive rounds the requested size, verify fails and names `nvme_op_nsze`. Set it to the value the drive reports.

## Tests
- Checked against nvme-cli source at **v2.16** (Rocky 10 BaseOS ships `nvme-cli-2.16-2.el10`) and at v2.11. What was checked:
  - command syntax: `create-ns`, `attach-ns`, `detach-ns`, `delete-ns`, `list-ns -a`, `reset`, `ns-rescan`
  - the `list-ns` output format, which is unchanged apart from a header line in 2.16
  - the `id-ctrl` and `id-ns` JSON keys
  - the `create-ns` success output. It changed in 2.16 (`create-ns: success` then `nsid: N`); the script parses both forms.

  Run `nvme version` on a ceph27a host to confirm.
- `test/mock_test.sh <dir>`: 34 checks of the script against a fake nvme-cli and sysfs. They cover:
  - both `create-ns` output formats
  - an `unvmcap` a little under `tnvmcap`
  - resize and its no-op rerun
  - the Ceph check: a BlueStore label, an LVM PV (on the disk or a partition), an active OSD LV, a mount, a probe error and a missing block device all block; a non-Ceph filesystem or a plain partition does not
  - serial filter
  - 4K format, a metadata format
  - a drive that rounds sizes
  - recovery after an interrupted delete
  - no namespace management support, a dual-controller subsystem
- `test/ansible_test.sh <dir>`: 12 checks running the role on localhost against the mock:
  - a count mismatch fails with nothing touched
  - one drive with a BlueStore label fails the play with neither drive touched
  - plan-only changes nothing
  - apply resizes and leaves the boot drive alone
  - the rerun ends the host early with `changed=0`
- Both need bash 4+, jq and ansible-core. They prove the logic, not the drives.
