#!/usr/bin/env bash
# nvme-op: one namespace of the target size per allow-listed NVMe drive; unallocated capacity is over-provisioning.
#   nvme-op plan            one JSON line per controller: done | todo | blocked | skip
#   nvme-op apply <serial>  resize one todo drive, then verify
# Settings: NVME_OP_* variables (role defaults/main.yml).
set -euo pipefail

SYSFS=${NVME_OP_SYSFS:-/sys/class/nvme}   # overridable for the mock test only
DEV=${NVME_OP_DEV:-/dev}
MODELS=${NVME_OP_MODELS:?NVME_OP_MODELS (newline-separated model numbers) is required}
BYTES=${NVME_OP_BYTES:-6400000000000}
NSZE_OVERRIDE=${NVME_OP_NSZE:-}
LBAF_OVERRIDE=${NVME_OP_LBAF:-}
SERIALS=${NVME_OP_SERIALS:-}
RESET=${NVME_OP_RESET:-1}
DPS=${NVME_OP_DPS:-0}

die() { echo "nvme-op: $*" >&2; exit 1; }
trim() { local s=$1; s=${s#"${s%%[![:space:]]*}"}; printf '%s' "${s%"${s##*[![:space:]]}"}"; }
in_list() {  # $1 value, $2 newline/comma-separated list
  local l
  while IFS= read -r l; do
    l=$(trim "$l"); [ -n "$l" ] && [ "$l" = "$1" ] && return 0
  done <<<"$(tr ',' '\n' <<<"$2")"
  return 1
}
run() { echo "+ $*"; "$@"; }

# Decimal NSIDs from `nvme list-ns` normal output ("[   0]:0x1"); $2=-a lists allocated, not just attached.
nsids() {
  local h
  for h in $(nvme list-ns "$1" ${2:+"$2"} | sed -nE 's/^\[ *[0-9]+\]:(0x[0-9a-fA-F]+)$/\1/p'); do
    echo $((h))
  done
}

# Block device of namespace $2 on controller $1. Native multipath names the path nvmeXcYnZ, the device nvmeXnZ.
blockdev_of() {
  local p
  for p in "$SYSFS/$1"/nvme*n"$2"; do
    [ -e "$p" ] || continue
    echo "$DEV/$(basename "$p" | sed -E 's/c[0-9]+n/n/')"
    return 0
  done
}

# "ok", or why namespace block device $1 must not be reformatted. ceph-volume lays an OSD on a whole device
# as an LVM PV or a raw BlueStore label; blkid -p reads both from the disk, on the device and any partition.
ceph_check() {
  local out d t rc
  out=$(lsblk -Pnpo NAME,TYPE,MOUNTPOINTS "$1")
  if grep -Eq 'MOUNTPOINTS="[^"]+"' <<<"$out"; then echo "mounted"; return; fi
  if grep -Eq 'TYPE="(lvm|crypt|raid[0-9]*|md|dm|mpath)"' <<<"$out"; then echo "in use by LVM/dm/md"; return; fi
  for d in $(grep -E 'TYPE="(disk|part)"' <<<"$out" | grep -oE '^NAME="[^"]+"' | cut -d'"' -f2); do
    rc=0; t=$(blkid -p -o value -s TYPE "$d") || rc=$?
    if (( rc != 0 && rc != 2 )); then echo "blkid -p $d failed (rc $rc)"; return; fi
    case $t in
      ceph_bluestore) echo "$d has a Ceph BlueStore label"; return ;;
      LVM2_member) echo "$d is an LVM PV (how ceph-volume lays out OSDs)"; return ;;
    esac
  done
  echo ok
}

controllers() {
  local p
  for p in "$SYSFS"/nvme*; do
    [[ $(basename "$p") =~ ^nvme[0-9]+$ ]] && basename "$p"
  done
  return 0
}

# Controllers sharing this controller's subsystem (dual-port drives): attach lists would need all of them.
subsys_ctrl_count() {
  local nqn n=0 p
  nqn=$(cat "$SYSFS/$1/subsysnqn")
  for p in $(controllers); do
    [ "$(cat "$SYSFS/$p/subsysnqn")" = "$nqn" ] && n=$((n + 1))
  done
  echo "$n"
}

# One JSON object describing controller $1 and what apply would do to it.
plan_one() {
  local c=$1 d="$DEV/$1" ctrl mn sn fr oacs cntlid tnvm unvm alloc att first ns={} cur_lbaf="" cur_nsze=0 cur_ncap=0
  local lbaf ds ms bs=0 nsze=0 state="" reason="" n dev u nalloc
  ctrl=$(nvme id-ctrl "$d" -o json)
  mn=$(trim "$(jq -r .mn <<<"$ctrl")"); sn=$(trim "$(jq -r .sn <<<"$ctrl")"); fr=$(trim "$(jq -r .fr <<<"$ctrl")")
  oacs=$(jq -r .oacs <<<"$ctrl"); cntlid=$(jq -r .cntlid <<<"$ctrl")
  tnvm=$(jq -r '.tnvmcap // 0' <<<"$ctrl"); unvm=$(jq -r '.unvmcap // 0' <<<"$ctrl")
  alloc=$(nsids "$d" -a | paste -sd, -); att=$(nsids "$d" | paste -sd, -)

  emit() {
    jq -cn --arg ctrl "$c" --arg model "$mn" --arg serial "$sn" --arg fw "$fr" --argjson cntlid "$cntlid" \
      --argjson tnvmcap "$tnvm" --argjson unvmcap "$unvm" --arg allocated "$alloc" --arg attached "$att" \
      --arg lbaf_now "$cur_lbaf" --argjson nsze_now "$cur_nsze" --arg lbaf "${lbaf:-}" --argjson block_size "$bs" \
      --argjson nsze_target "$nsze" --arg state "$state" --arg reason "$reason" \
      '{ctrl:$ctrl, model:$model, serial:$serial, fw:$fw, cntlid:$cntlid, tnvmcap:$tnvmcap, unvmcap:$unvmcap,
        allocated:$allocated, attached:$attached, lbaf_now:$lbaf_now, nsze_now:$nsze_now, lbaf:$lbaf,
        block_size:$block_size, nsze_target:$nsze_target, bytes_target:($nsze_target * $block_size),
        state:$state, reason:$reason}'
  }

  if ! in_list "$mn" "$MODELS"; then state=skip; reason="model not in nvme_op_models"; emit; return; fi
  if [ -n "$SERIALS" ] && ! in_list "$sn" "$SERIALS"; then state=skip; reason="serial not in nvme_op_serials"; emit; return; fi
  if (( (oacs & 8) == 0 )); then state=blocked; reason="no namespace management (OACS bit 3 clear)"; emit; return; fi
  n=$(subsys_ctrl_count "$c")
  if (( n != 1 )); then state=blocked; reason="subsystem has $n controllers; handle by hand"; emit; return; fi

  first=${alloc%%,*}
  if [ -n "$first" ]; then
    ns=$(nvme id-ns "$d" -n "$first" -o json)
    cur_lbaf=$(( $(jq -r .flbas <<<"$ns") & 0xf )); cur_nsze=$(jq -r .nsze <<<"$ns"); cur_ncap=$(jq -r .ncap <<<"$ns")
  else
    # No namespace left (an earlier apply stopped after delete): the common namespace capabilities list the formats.
    ns=$(nvme id-ns "$d" -n 0xffffffff -o json || echo '{}')
  fi
  lbaf=${LBAF_OVERRIDE:-$cur_lbaf}
  if [ -z "$lbaf" ]; then state=blocked; reason="no namespace to read the LBA format from; set nvme_op_lbaf"; emit; return; fi
  ds=$(jq -r ".lbafs[$lbaf].ds // 0" <<<"$ns"); ms=$(jq -r ".lbafs[$lbaf].ms // 0" <<<"$ns")
  if (( ds < 9 )); then state=blocked; reason="LBA format $lbaf not reported by the drive"; emit; return; fi
  if (( ms != 0 )); then state=blocked; reason="LBA format $lbaf carries metadata (ms=$ms); pick a format with ms=0"; emit; return; fi
  bs=$((1 << ds)); nsze=${NSZE_OVERRIDE:-$((BYTES / bs))}
  if (( tnvm > 0 && nsze * bs >= tnvm )); then state=blocked; reason="target $((nsze * bs)) B is not below capacity $tnvm B"; emit; return; fi

  nalloc=$(tr ',' '\n' <<<"$alloc" | grep -c . || true)
  if (( nalloc == 1 )) && [ "$att" = "$alloc" ] && (( cur_nsze == nsze && cur_ncap == nsze )) && [ "$cur_lbaf" = "$lbaf" ]; then
    state=done; emit; return
  fi

  # Not yet formatted: refuse if Ceph has anything on an attached namespace.
  for n in $(tr ',' ' ' <<<"$att"); do
    dev=$(blockdev_of "$c" "$n")
    if [ -z "$dev" ] || [ ! -e "$dev" ]; then state=blocked; reason="namespace $n has no block device to check"; emit; return; fi
    u=$(ceph_check "$dev")
    if [ "$u" != ok ]; then state=blocked; reason="$u"; emit; return; fi
  done
  state=todo; reason="delete namespaces [$alloc], create nsid of $nsze x $bs B (LBA format $lbaf), attach"
  emit
}

plan() {
  local c
  for c in $(controllers); do plan_one "$c"; done
}

wait_for() {  # $1 seconds, $2.. test command; polls once a second
  local t=$1 i; shift
  for ((i = 0; i < t; i++)); do "$@" && return 0; sleep 1; done
  return 1
}
ctrl_live() { [ "$(cat "$SYSFS/$1/state")" = live ]; }
ns_present() { local b; b=$(blockdev_of "$1" "$2"); [ -n "$b" ] && [ -e "$b" ]; }

apply() {
  local serial=$1 c="" x rec state d alloc att cntlid nsze lbaf bs out new ctrl tnvm unvm dev size n
  for x in $(controllers); do
    [ "$(trim "$(nvme id-ctrl "$DEV/$x" -o json | jq -r .sn)")" = "$serial" ] && { [ -z "$c" ] || die "serial $serial on $c and $x"; c=$x; }
  done
  [ -n "$c" ] || die "no NVMe controller with serial $serial"
  d="$DEV/$c"
  rec=$(plan_one "$c"); state=$(jq -r .state <<<"$rec")
  case $state in
    done) echo "$rec"; echo "nvme-op: $serial ($c) already done"; return 0 ;;
    todo) ;;
    *) echo "$rec"; die "$serial ($c) is $state: $(jq -r .reason <<<"$rec")" ;;
  esac
  alloc=$(jq -r .allocated <<<"$rec"); att=$(jq -r .attached <<<"$rec"); cntlid=$(jq -r .cntlid <<<"$rec")
  nsze=$(jq -r .nsze_target <<<"$rec"); lbaf=$(jq -r .lbaf <<<"$rec"); bs=$(jq -r .block_size <<<"$rec")
  echo "nvme-op: $serial on $c: $(jq -r .reason <<<"$rec")"

  for n in $(tr ',' ' ' <<<"$alloc"); do
    if in_list "$n" "$att"; then run nvme detach-ns "$d" -n "$n" -c "$cntlid"; fi
    run nvme delete-ns "$d" -n "$n"
  done

  ctrl=$(nvme id-ctrl "$d" -o json); tnvm=$(jq -r '.tnvmcap // 0' <<<"$ctrl"); unvm=$(jq -r '.unvmcap // 0' <<<"$ctrl")
  [ -z "$(nsids "$d" -a)" ] || die "$c still has namespaces after delete: $(nsids "$d" -a | paste -sd, -)"
  # Room check only: firmware may report unvmcap a little under tnvmcap, and a strict equality here
  # would strand a drive with no namespace on every rerun.
  (( tnvm == 0 || unvm >= nsze * bs )) || die "$c has $unvm B unallocated after delete, needs $((nsze * bs)) B"

  out=$(run nvme create-ns "$d" --nsze="$nsze" --ncap="$nsze" --flbas="$lbaf" --dps="$DPS")
  echo "$out"
  # nvme-cli <= 2.11: "create-ns: Success, created nsid:1"; 2.16 (Rocky 10): "create-ns: success" then "nsid: 1".
  new=$(sed -nE -e 's/.*created nsid:([0-9]+).*/\1/p' -e 's/^nsid: *([0-9]+)$/\1/p' <<<"$out")
  [ -n "$new" ] || die "create-ns on $c reported no nsid"
  run nvme attach-ns "$d" -n "$new" -c "$cntlid"
  if [ "$RESET" = 1 ]; then
    run nvme reset "$d"
    wait_for 60 ctrl_live "$c" || die "$c not live 60 s after reset"
  fi
  run nvme ns-rescan "$d"
  wait_for 60 ns_present "$c" "$new" || die "namespace $new on $c has no block device after 60 s"
  udevadm settle

  rec=$(plan_one "$c"); echo "$rec"
  [ "$(jq -r .state <<<"$rec")" = done ] \
    || die "$c verify failed (nsze now $(jq -r .nsze_now <<<"$rec"), wanted $nsze); if the drive rounds sizes, set nvme_op_nsze to what it reports"
  dev=$(blockdev_of "$c" "$new"); size=$(blockdev --getsize64 "$dev")
  (( size == nsze * bs )) || die "$dev is $size B, expected $((nsze * bs))"
  echo "nvme-op: $serial ($c) done: $dev $size B"
  nvme list | grep -F "$serial" || true
}

case ${1:-} in
  plan) plan ;;
  apply) apply "${2:?usage: nvme-op apply <serial>}" ;;
  *) die "usage: nvme-op plan | apply <serial>" ;;
esac
