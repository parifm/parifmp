#!/usr/bin/env bash
# Send an alert email through every transport defined in alert.conf (next to this script): an open SMTP relay,
# an authenticated SMTP relay (STARTTLS), and/or the local MTA (postfix, set up by mta.yml). Body on stdin.
# Exit 0 if at least one transport accepted the message, 1 if none did or none is defined.
# Usage: alert.sh "<subject>" < body
set -uo pipefail
HERE=$(cd "$(dirname "$0")" && pwd)
CONF=${ALERT_CONF:-$HERE/alert.conf}
subject=${1:?subject}

ALERT_EMAIL=alerts@generic.address.com
ALERT_FROM="ceph27a-ansible@$(hostname -f)"
SMTP_RELAY=""            # host[:port], no auth (port 25 default)
SMTP_AUTH_RELAY=""       # host[:port], STARTTLS + login (port 587 default)
SMTP_AUTH_USER=""
SMTP_AUTH_PASS=""
MTA=""                   # yes = hand the message to the local sendmail (postfix)
# shellcheck source=/dev/null
[ -r "$CONF" ] && . "$CONF"

tmp=$(mktemp -d) || exit 1
trap 'rm -r -- "${tmp:?}"' EXIT
{
  printf 'From: %s\nTo: %s\nSubject: %s\nDate: %s\nMessage-ID: <%s.%s@%s>\nContent-Type: text/plain; charset=utf-8\n\n' \
    "$ALERT_FROM" "$ALERT_EMAIL" "$subject" "$(date -R)" "$(date +%s)" "$$" "$(hostname -f)"
  cat
} > "$tmp/msg"

rcpts=()
IFS=, read -ra list <<<"$ALERT_EMAIL"
for r in "${list[@]}"; do rcpts+=(--mail-rcpt "${r// /}"); done

sent=0 tried=0
if [ -n "$SMTP_RELAY" ]; then
  tried=$((tried + 1)); h=${SMTP_RELAY%%:*}; p=${SMTP_RELAY#*:}; [ "$p" = "$SMTP_RELAY" ] && p=25
  if curl -sS --max-time 60 --url "smtp://$h:$p" --mail-from "${ALERT_FROM}" "${rcpts[@]}" -T "$tmp/msg"; then
    echo "alert: sent via SMTP relay $h:$p"; sent=$((sent + 1))
  else echo "alert: SMTP relay $h:$p FAILED" >&2; fi
fi
if [ -n "$SMTP_AUTH_RELAY" ]; then
  tried=$((tried + 1)); h=${SMTP_AUTH_RELAY%%:*}; p=${SMTP_AUTH_RELAY#*:}; [ "$p" = "$SMTP_AUTH_RELAY" ] && p=587
  ( umask 077; printf 'user = "%s:%s"\n' "$SMTP_AUTH_USER" "$SMTP_AUTH_PASS" > "$tmp/curl.cfg" )
  if curl -sS --max-time 60 --ssl-reqd --url "smtp://$h:$p" -K "$tmp/curl.cfg" --mail-from "${ALERT_FROM}" "${rcpts[@]}" -T "$tmp/msg"; then
    echo "alert: sent via authenticated relay $h:$p"; sent=$((sent + 1))
  else echo "alert: authenticated relay $h:$p FAILED" >&2; fi
fi
if [ "$MTA" = yes ]; then
  tried=$((tried + 1))
  if /usr/sbin/sendmail -t -f "$ALERT_FROM" < "$tmp/msg"; then
    echo "alert: queued via local MTA"; sent=$((sent + 1))
  else echo "alert: local MTA FAILED" >&2; fi
fi

[ "$tried" -eq 0 ] && echo "alert: no transport defined in $CONF; subject was: $subject" >&2
[ "$sent" -gt 0 ]
