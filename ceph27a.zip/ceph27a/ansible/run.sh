#!/usr/bin/env bash
# Run a play and email an alert (alert.sh) if it fails for any reason: a failed task, an unreachable host,
# a syntax error or an interrupted run. The full output is kept in logs/<play>-<UTC time>.log.
# Usage: ./run.sh <play.yml> [ansible-playbook args...]     e.g. ./run.sh patch.yml --limit 'ceph:!ceph27a-1'
set -uo pipefail
HERE=$(cd "$(dirname "$0")" && pwd)
play=${1:?play}; shift
mkdir -p "$HERE/logs"
log=$HERE/logs/$(basename "$play" .yml)-$(date -u +%Y%m%dT%H%M%SZ).log

cd "$HERE" || exit 1
ansible-playbook "$play" "$@" 2>&1 | tee "$log"
rc=${PIPESTATUS[0]}

if [ "$rc" -ne 0 ]; then
  {
    echo "ansible-playbook $play $* exited $rc on $(hostname -f) at $(date -u +%Y-%m-%dT%H:%M:%SZ)."
    echo "Full log: $log"
    echo
    echo "== failures"
    grep -E '^(fatal|failed):|^ERROR!' "$log" | cut -c1-600 | tail -20
    echo
    echo "== recap"
    sed -n '/^PLAY RECAP/,$p' "$log"
    echo
    echo "== last 40 lines"
    tail -40 "$log"
  } | "$HERE/alert.sh" "ceph27a: $play FAILED (rc $rc) on $(hostname -s)"
fi
exit "$rc"
