#!/usr/bin/env bash
# Poll until <host>'s OSDs are up, its daemons run, every PG is active+clean, all <rgws> RGWs run and the cluster is
# HEALTH_OK. Exit 0 when healthy, 1 at <cap> seconds. The latest reasons for waiting go to /var/tmp/ceph27a-wait.status.
# Usage: wait_healthy.sh <host> <rgws> <cap seconds>
set -uo pipefail
host=${1:?host} rgws=${2:?rgw count} cap=${3:?cap seconds}
status=/var/tmp/ceph27a-wait.status
c() { cephadm shell -- ceph "$@" --format json 2>&1 | grep -v '^Inferring'; }
start=$(date +%s)
while :; do
  why=""
  c osd tree-from "$host" | jq -e '[.nodes[] | select(.type == "osd" and .status != "up")] | length == 0' >/dev/null || why+=" osds-not-up"
  c pg stat | jq -e '.pg_summary as $s | ([$s.num_pg_by_state[] | select(.name == "active+clean").num] | add // 0) == $s.num_pgs' >/dev/null || why+=" pgs-not-active+clean"
  c orch ps "$host" --refresh | jq -e '[.[] | select(.status_desc != "running")] | length == 0' >/dev/null || why+=" host-daemons-not-running"
  c orch ls rgw | jq -e --argjson n "$rgws" '.[0].status.running == $n' >/dev/null || why+=" rgws-not-all-running"
  c health | jq -e '.status == "HEALTH_OK"' >/dev/null || why+=" not-HEALTH_OK"
  waited=$(( $(date +%s) - start ))
  echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) waited ${waited}s:${why:- healthy}" > "$status"
  [ -z "$why" ] && { echo "healthy after ${waited}s"; exit 0; }
  [ "$waited" -ge "$cap" ] && { echo "still not healthy after ${waited}s:$why"; exit 1; }
  sleep 20
done
